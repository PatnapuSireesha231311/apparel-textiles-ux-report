# Thread & Loom — Apparel & Textiles UX Prototype Report

This repository contains the Week 2 front-end prototype design and UX strategy report.

## Contents
- `Apparel_Textiles_Frontend_Prototype_UX_Report.docx` — formatted report with wireframes, UX flow, design rationale, testing plan, and references.
- `figures/` — source wireframe images used in the report.

## Project summary
Thread & Loom is a conceptual responsive apparel and textiles storefront. The report covers information architecture, visual design, mobile/desktop behaviour, accessibility, shopping flow, and iterative user testing.

## How to use
1. Download the DOCX report.
2. Open it in Microsoft Word or LibreOffice.
3. Replace the project name or add your name/course details if required.
4. Upload the files to your GitHub repository using the commands in `GITHUB_UPLOAD.md`.
